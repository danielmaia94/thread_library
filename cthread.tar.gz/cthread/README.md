cthread 
 
Work of Operation Systems 1 at the UFRGS 
 
Students: 
 
Daniel Maia 
Denyson Grellert 
Felipe Tormes 
 
 
This work is a library that implements user threads, called here of cthreads. 